package sg.edu.rp.c346.reservation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextView tvName, tvPhone, tvPax;
    EditText etName, etPhone, etPax;
    Button btnReserve, btnReset;
    CheckBox cbSmoke;
    DatePicker dpDate;
    TimePicker tpTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvName = findViewById(R.id.textViewName);
        etName = findViewById(R.id.editTextName);
        tvPhone = findViewById(R.id.textViewPhone);
        etPhone = findViewById(R.id.editTextPhone);
        tvPax = findViewById(R.id.textViewPax);
        etPax = findViewById(R.id.editTextPax);
        cbSmoke = findViewById(R.id.checkBoxSmoke);
        dpDate = findViewById(R.id.datePickerDate);
        tpTime = findViewById(R.id.timePickerTime);
        btnReserve = findViewById(R.id.buttonReserve);
        btnReset = findViewById(R.id.buttonReset);

        btnReserve.setOnClickListener(
                (new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String getName = etName.getText().toString().trim();
                        String getPhone = etPhone.getText().toString().trim();
                        String getPax = etPax.getText().toString().trim();
                        if (getName.length() != 0 || getPhone.length() != 0 || getPax.length() != 0) {
                            String isSmoke = "";
                            if (cbSmoke.isChecked()) {
                                isSmoke = "Smoking";
                            } else {
                             isSmoke = "Non-Smoking";
                            }

                            int getYr = dpDate.getYear();
                            int getMonth = dpDate.getMonth();
                            int getDay = dpDate.getDayOfMonth();
                            int getHr = tpTime.getCurrentHour();
                            int getMin = tpTime.getCurrentMinute();

                            Calendar newDate = Calendar.getInstance();
                            newDate.set(getYr, getMonth, getDay, getHr, getMin);
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/YYYY hh:mm a");

                            Calendar now = Calendar.getInstance();
                            if (now.after(newDate)) {
                                Toast.makeText(MainActivity.this, "Date selected cannot be in the past", Toast.LENGTH_LONG).show();
                                return;
                            }

                            String fullDate = getDay + "/" + getMonth + "/" + getYr;
                            String fullTime = getHr + getMin + "hrs";
                            String output = "Hi, " + getName + " , you have booked for " + getPax + " person(s) on the " + sdf.format(newDate.getTime()) + ". " + isSmoke + "\nYour contact number is " + getPhone;

                            Toast.makeText(MainActivity.this, output, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Please ensure all info are filled up!", Toast.LENGTH_LONG).show();
                        }


                    }
                })
        );

        btnReset.setOnClickListener(
                (new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        etName.setText(null);
                        etPhone.setText(null);
                        etPax.setText(null);
                        cbSmoke.setChecked(false);
                        dpDate.updateDate(2018, 05, 9);
                    }
                })
        );
    }
}
